define({
  "name": "Todo Application",
  "version": "0.0.1",
  "description": "Documentation for the Todo app",
  "title": "Todo APIs",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-05-19T19:24:13.449Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
